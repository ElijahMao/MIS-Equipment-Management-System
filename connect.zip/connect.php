<?php
mysql_connect("localhost","root","holy1688");//連結伺服器
mysql_select_db("mis");//選擇資料庫
mysql_query("set names utf8");//以utf8讀取資料，讓資料可以讀取中文
?>